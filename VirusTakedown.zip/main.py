#Somehow, main.py broke, and only copy.py runs.
import pygame
import random
from classes import Virus, WhiteBloodCell, is_next_to, Antibody, BodyPart

pygame.font.init()
pygame.init()
#colors we will need
white = (255, 255, 255)
black = (0, 0, 0)
red = (255, 0, 0)
blue = (0, 0, 255)
#FPS CAP
FPS = 60
clock = pygame.time.Clock()
#Resolution
Screen = pygame.display.set_mode((400, 400))
#Caption
pygame.display.set_caption('Virus Takedown')

def immunize(color):
	global immuneSystem
	for cell in immuneSystem:
		if type(cell) == WhiteBloodCell and color == None:
			WhiteBloodCell.color = color
	immuneSystem.append(Antibody(0,360,color,location,random.choice(location.viruses)))
	immuneSystem.append(Antibody(0,320,color,location,random.choice(location.viruses)))

#The three locations
brain = BodyPart("brain")
skin = BodyPart("skin")
lungs = BodyPart("lungs")

for i in range(3):
	brain.viruses.append(
		Virus(random.randrange(20, 400, 40), random.randrange(20, 400, 40), "rabies", None, 1))
	skin.viruses.append(
		Virus(random.randrange(20, 400, 40), random.randrange(20, 400, 40), "pox", None, 1))
	lungs.viruses.append(
		Virus(random.randrange(20, 400, 40), random.randrange(20, 400, 40), "flu", blue, 1))

location = lungs
order = [brain, skin, lungs, brain]
backgrounds = {
	brain: (0, 0, 64),
	skin: (64, 0, 0),
	lungs: (0, 64, 0)
}

immuneSystem = [
	WhiteBloodCell(20, 20, None),
	WhiteBloodCell(120, 20, None),
	WhiteBloodCell(220, 20, None),
	WhiteBloodCell(320, 20, None)
]

#this is test code
for i in range(1):
	immuneSystem.append(Antibody(400,20,None,lungs,random.choice(location.viruses)))

#Main Loop
running = True
while running:
	clock.tick(FPS)
	Screen.fill(backgrounds[location])
	pygame.draw.rect(Screen, red, (0, 0, 400, 40), border_radius=1)

	for i in range(0, 400, 40):  #the grid
		pygame.draw.line(Screen, white, (0, i), (400, i))
		pygame.draw.line(Screen, white, (i, 0), (i, 400))

	for virus in location.viruses:
		virus.display(Screen)
		virus.maintain(location.viruses)

	for cell in immuneSystem:
		if type(cell) == Antibody:
			if cell.location == location:
				cell.display(Screen)
				cell.attack(location.viruses)

	control = immuneSystem[0]

	for cell in immuneSystem:
		if type(cell) == WhiteBloodCell:
			cell.display(Screen)
			if cell != control:
				cell.x += 0.3
			if cell.x > 400:
				cell.x = 0
			if cell.y > 400:
				cell.y = 0
			if cell.x < 0:
				cell.x = 400
			if cell.y < 0:
				cell.y = 400

	font = pygame.font.SysFont("sans", 20)
	text = font.render(location.name, True, (0, 0, 0))
	text_rect = text.get_rect()
	text_rect.center = (40, 20)
	Screen.blit(text, text_rect)

	if len(location.viruses) > 15:
		#all of the stuff that has changed since the beginning of the game has to reset
		immunize(blue)
		import copy
		break
		'''
		brain.viruses = []
		lungs.viruses = []
		skin.viruses = []
		for i in range(3):
			brain.viruses.append(Virus(random.randrange(20, 400, 40), random.randrange(20, 400, 40), "rabies", None, 1))
			skin.viruses.append(Virus(random.randrange(20, 400, 40), random.randrange(20, 400, 40), "pox", None, 1))
			lungs.viruses.append(Virus(random.randrange(20, 400, 40), random.randrange(20, 400, 40), "flu", blue, 1))
		location = lungs
		immuneSystem = [ WhiteBloodCell(20, 20, blue), WhiteBloodCell(120, 20, blue), WhiteBloodCell(220, 20, blue), WhiteBloodCell(320, 20, blue), Antibody(400,400,)]
		for i in range(1):
			immuneSystem.append(Antibody(400,20,None,lungs,random.choice(location.viruses)))
		'''		


	#print(location.name)

	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			print("ending game. . .")
			running = False
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_SPACE:
				location = order[order.index(location) + 1]  #goes to the next location in order
				control.y = 20
			if event.key == pygame.K_UP:
				control.y -= 4
			if event.key == pygame.K_DOWN:
				control.y += 4
			if event.key == pygame.K_LEFT:
				control.x -= 4
			if event.key == pygame.K_RIGHT:
				control.x += 4
			if event.key == pygame.K_BACKSPACE:
				for virus in location.viruses:
					if is_next_to((virus.x, virus.y), (control.x, control.y)):
						if control.color == virus.color:
							virus.health -= 0.975
						virus.health -= 0.001
			#if event.key == pygame.K_a:
			
			#	immuneSystem.append(Antibody(0,360,blue,location,random.choice(location.viruses)))
			#if event.key == pygame.K_v:
			#	location.viruses.append(Virus(random.randrange(20, 400, 40), random.randrange(20, 400, 40), "flu", blue, 1))
		'''
		if event.type == pygame.MOUSEBUTTONDOWN:
			mouse_coords = event.pos  #gets mouse position
			for cell in immuneSystem:
				if cell.collidepoint(mouse_coords):
					control = cell
					if is_next_to((mouse_coords[0], mouse_coords[1]),(cell.x, cell.y)):
						print("a")
						control = cell
		'''

	pygame.display.update()
