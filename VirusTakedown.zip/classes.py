from colorsys import hls_to_rgb
import pygame
import random
from math import sqrt

standardColor = {"rabies": (128, 128, 128), "pox": (128, 64, 0), "flu": (0, 0, 255)}

def flu_color(hue):
	tuple((x * 255 for x in hls_to_rgb(hue, 0.5, 1) ))

class BodyPart:
	def __init__(self, name):
		self.viruses = []
		self.name = name

class Virus:
	def __init__(self, x, y, species, color, health):
		self.species = species
		self.x = x
		self.y = y
		self.health = health
		if species == "pox":
			self.color = (128, 64, 0)
		elif species == "rabies":
			self.color = (128, 128, 128)
		else:
			self.color = color
		#if you want to initialize a pox or rabies virus, just set the color to None.
	def display(self, surface):
		pygame.draw.polygon(surface, self.color, (
		(self.x, self.y+15),
		(self.x+15, self.y),
		(self.x, self.y-15),
		(self.x-15, self.y)
		))
	def die(self):
		del self
	def reproduce(self, location):
		x = self.x
		y = self.y
		adjacent = [
			(x - 40, y - 40),
			(x, y - 40),
			(x + 40, y - 40),
			(x + 40, y),
			(x + 40, y + 40),
			(x, y + 40),
			(x - 40, y + 40),
			(x - 40, y)
		]
		for space in adjacent:
			if space[0] < 0 or space[0] > 400 or space[1] < 0 or space[1] > 400:
				adjacent.remove(space)
				
				
		for virus in location:
			for space in adjacent:
				if space == (virus.x, virus.y):
					adjacent.remove(space)
		try:
			newSpace = random.choice(adjacent)
			location.append(Virus(newSpace[0], newSpace[1], self.species, standardColor[self.species], 1))
			print("reproduced in", newSpace[0],newSpace[1])
			print(len(location))
		except:
			#self.health -= 0.001
			print("unable to reproduce")
	def maintain(self, location):
		if random.random() < 0.001: #this number is the reproduction rate
			self.reproduce(location)
		if self.health != 1:
			self.health -= 0.001
			self.color = (128,0,0)
		if self.health <= 0:
			location.remove(self)  #virus death.
		if self.x < 0 or self.x > 400 or self.y < 0 or self.y > 400:
			location.remove(self)
			print("virus in an invalid spot")

class WhiteBloodCell:
	def __init__(self, x, y, color):
		self.color = color
		self.x = x
		self.y = y
	def display(self, surface):
		pygame.draw.circle(surface, (255, 255, 255), (self.x, self.y), 15)

class Antibody:
	def __init__(self, x, y, color, location, target):
		self.color = color
		self.x = x
		self.y = y
		self.target = target
		self.location = location
	def display(self, surface):
		var = sqrt(3)
		pygame.draw.polygon(surface, (255, 255, 255), ( 
		(self.x, self.y - 4),
		(self.x - 2*var, self.y - 6),
		(self.x - 4*var, self.y),
		(self.x - 2*var, self.y + 2),
		(self.x - 2*var, self.y + 6),
		(self.x + 2*var, self.y + 6),
		(self.x + 2*var, self.y + 2),
		(self.x + 4*var, self.y),
		(self.x + 2*var, self.y - 6)
		))
	def attack(self, location):
		try:
			
			vector = (self.target.x - self.x, self.target.y - self.y)
			magnitude = sqrt( vector[0]**2 + vector[1]**2 )
			vector = (vector[0] / magnitude, vector[1] / magnitude) #calculate vector to go towards virus
	
			self.x += vector[0]
			self.y += vector[1]
			
			if is_next_to( (self.target.x, self.target.y), (self.x,self.y) ):
				self.target.health -= 0.001
		except:
			vector = (0,0)
	
		if (self.target not in location):
			try:
				self.target = random.choice(location)
			except:
				self.target = None
			

def is_next_to(pair1, pair2):
	return abs(pair1[0] - pair2[0]) < 20 and abs(pair1[1] - pair2[1]) < 20